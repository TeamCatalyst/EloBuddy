﻿using System;
using EloBuddy.SDK;
using EloBuddy.SDK.Events;
using EloBuddy;
using System.Collections.Generic;
using Catalyst_Twitch.Modes;

namespace Catalyst_Twitch
{
    class Twitch
    {
        public static AIHeroClient Player
        {
            get { return ObjectManager.Player; }
        }

        private static List<ModeBase> AvailableModes { get; set; }

        static void Main(string[] args)
        {
            Loading.OnLoadingComplete += OnLoadingComplete;

            AvailableModes = new List<ModeBase>
            {
                new Combo(),
                new Harass(),
                new LaneClear(),
                new JungleClear(),
                new Flee()
            };

            Drawing.OnDraw += Drawings.OnDraw;
            Game.OnTick += OnTick;
        }

        private static void OnLoadingComplete(EventArgs args)
        {
            Bootstrap.Init(null);

            if (Player.ChampionName != Champion.Twitch.ToString())
            {
                return;
            }

            Options.Initialize();
            SpellManager.Initialize();
        }

        private static void OnTick(EventArgs args)
        {
            AvailableModes.ForEach(mode =>
            {
                if (mode.ShouldBeExecuted())
                {
                    mode.Execute();
                }
            });
        }
    }
}
