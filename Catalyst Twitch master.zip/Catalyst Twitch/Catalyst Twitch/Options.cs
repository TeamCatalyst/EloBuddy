﻿using EloBuddy.SDK.Menu;
using EloBuddy.SDK.Menu.Values;

namespace Catalyst_Twitch
{
    public static class Options
    {
        public const string ChampName = "Twitch";
        public const string Version = "0.0.0.1";
        private static Menu Menu, KSMenu, ModesMenu, DrawMenu;

        private static readonly CheckBox comboUseQ;
        private static readonly CheckBox comboUseW;
        private static readonly CheckBox comboUseE;
        private static readonly CheckBox comboUseR;

        private static readonly CheckBox harassUseW;
        private static readonly CheckBox harassUseE;

        private static readonly CheckBox lasthitUseE;

        private static readonly CheckBox jungleclearUseW;
        private static readonly CheckBox jungleclearUseE;

        private static readonly CheckBox laneclearUseW;
        private static readonly CheckBox laneclearUseE;

        private static readonly CheckBox fleeUseQ;

        private static readonly CheckBox drawW;
        private static readonly CheckBox drawE;
        private static readonly CheckBox drawR;
        private static readonly CheckBox drawEDamage;

        private static readonly CheckBox ksUseW;
        private static readonly CheckBox ksUseE;
        private static readonly CheckBox ksUseR;

        public static bool DrawW
        {
            get { return drawW.CurrentValue; }
        }
        public static bool DrawE
        {
            get { return drawE.CurrentValue; }
        }
        public static bool DrawR
        {
            get { return drawR.CurrentValue; }
        }
        public static bool DrawEDamage
        {
            get { return drawEDamage.CurrentValue; }
        }
        public static bool ComboUseQ
        {
            get { return comboUseQ.CurrentValue; }
        }
        public static bool ComboUseW
        {
            get { return comboUseW.CurrentValue; }
        }
        public static bool ComboUseE
        {
            get { return comboUseE.CurrentValue; }
        }

        static Options()
        {
            //0
            Menu = MainMenu.AddMenu("Team Catalyst", "twitchMenu");

            Menu.AddGroupLabel("Catalyst - " + ChampName);
            Menu.AddLabel("Enjoy Team Catalyst Addons");
            Menu.AddLabel("This is Version " + Version);
            Menu.AddSeparator();
            Menu.AddLabel("Thank you for choosing our Addon! Feel free to send feedback or requests");
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddSeparator();
            Menu.AddLabel("By Team Catalyst");
            //0

            //1
            DrawMenu = Menu.AddSubMenu("Draw");

            DrawMenu.AddGroupLabel("Draw Menu");
            drawW = DrawMenu.Add("drawW", new CheckBox("Draw W"));
            drawE = DrawMenu.Add("drawE", new CheckBox("Draw E"));
            drawR = DrawMenu.Add("drawR", new CheckBox("Draw R"));
            drawEDamage = DrawMenu.Add("drawEDamage", new CheckBox("Draw E damage on healthbar"));
            //1

            //2
            ModesMenu = Menu.AddSubMenu("Modes", "modes");

            ModesMenu.AddGroupLabel("Mode Menu");
            ModesMenu.AddLabel("Combo");
            comboUseQ = ModesMenu.Add("comboUseQ", new CheckBox("Use Q"));
            comboUseW = ModesMenu.Add("comboUseW", new CheckBox("Use W"));
            comboUseE = ModesMenu.Add("comboUseE", new CheckBox("Use E"));
            comboUseR = ModesMenu.Add("comboUseR", new CheckBox("Use R"));
            ModesMenu.AddSeparator();
            ModesMenu.AddLabel("Harass");
            harassUseW = ModesMenu.Add("harassUseW", new CheckBox("Use W"));
            harassUseE = ModesMenu.Add("harassUseE", new CheckBox("Use E"));
            ModesMenu.AddSeparator();
            ModesMenu.AddLabel("LastHit");
            lasthitUseE = ModesMenu.Add("lasthitUseE", new CheckBox("Use E"));
            ModesMenu.AddSeparator();
            ModesMenu.AddLabel("JungleClear");
            jungleclearUseW = ModesMenu.Add("jungleclearUseW", new CheckBox("Use W"));
            jungleclearUseE = ModesMenu.Add("jungleclearUseE", new CheckBox("Use E"));
            ModesMenu.AddSeparator();
            ModesMenu.AddLabel("LaneClear");
            laneclearUseW = ModesMenu.Add("laneclearUseW", new CheckBox("Use W"));
            laneclearUseE = ModesMenu.Add("laneclearUseE", new CheckBox("Use E"));
            ModesMenu.AddSeparator();
            ModesMenu.AddLabel("Flee");
            fleeUseQ = ModesMenu.Add("fleeUseQ", new CheckBox("Use Q"));
            //2

            //3
            KSMenu = Menu.AddSubMenu("KS", "ks");

            KSMenu.AddGroupLabel("KillSteal Menu");
            ksUseW = KSMenu.Add("ksUseW", new CheckBox("Killsteal with W"));
            ksUseE = KSMenu.Add("ksUseE", new CheckBox("Killsteal with E"));
            ksUseR = KSMenu.Add("ksUseR", new CheckBox("Killsteal with R"));
            //3
        }

        public static void Initialize()
        {
        }
    }
}
