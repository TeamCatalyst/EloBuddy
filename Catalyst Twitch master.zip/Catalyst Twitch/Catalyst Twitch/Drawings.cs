﻿using EloBuddy;
using EloBuddy.SDK.Rendering;
using System;
using Color = System.Drawing.Color;

namespace Catalyst_Twitch
{
    class Drawings
    {
        public static AIHeroClient Player
        {
            get { return ObjectManager.Player; }
        }

        public static void OnDraw(EventArgs args)
        {
            if (Player.IsDead)
            {
                return;
            }

            if (Options.DrawW && SpellManager.W.IsLearned)
            {
                new Circle { Color = Color.GreenYellow, BorderWidth = 1, Radius = SpellManager.W.Range }.Draw(Player.Position);
            }
            if (Options.DrawE && SpellManager.E.IsLearned)
            {
                new Circle { Color = Color.Red, BorderWidth = 1, Radius = SpellManager.E.Range }.Draw(Player.Position);
            }
            if (Options.DrawR && SpellManager.R.IsReady())
            {
                new Circle { Color = Color.SkyBlue, BorderWidth = 1, Radius = 900 }.Draw(Player.Position);
            }

            if (Options.DrawEDamage)
            {
                //DRAW DAT SHIT
            }
        }
    }
}
