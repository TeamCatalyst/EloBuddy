﻿using EloBuddy;
using EloBuddy.SDK;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Catalyst_Twitch.Modes
{

    public class Combo : ModeBase
    {

        public override bool ShouldBeExecuted()
        {
            return Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.Combo);
        }

        public override void Execute()
        {
            AIHeroClient target = TargetSelector.GetTarget(W.Range, DamageType.Physical);

            //Killsteal with E
            if (Options.ComboUseE && E.IsReady())
            {

                //foreach (var enemy in ObjectManager.Get<Obj_AI_Base>().Where(enemy => enemy.IsValidTarget(E.Range) && E.IsKillable(enemy)))
                //{
                //    E.Cast();
               // }
            }

            //Use W
            if (Options.ComboUseW && W.IsReady() && target.IsValidTarget(W.Range))
            {
                W.Cast(target);
            }
        }
    }
}
